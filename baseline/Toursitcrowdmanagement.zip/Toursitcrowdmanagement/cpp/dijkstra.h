#ifndef DIJKSTRA_H
#define DIJKSTRA_H

#include "Graph.h"
#include <vector>
using namespace std;

vector<int> dijkstra(Graph& g, int src);

#endif
