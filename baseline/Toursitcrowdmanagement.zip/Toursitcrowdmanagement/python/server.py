from itinerary_planner import ItineraryPlanner
import json
from flask import Flask, request, jsonify, send_from_directory

app = Flask(__name__)

@app.route('/')
def serve_planner():
    return send_from_directory('.', 'planner.html')

# Example Floyd-Warshall matrix (replace with your real data)
fw_matrix = [
    # Distances between nodes, 10x10 for example
    [0, 10, 15, 20, 25, 30, 35, 40, 45, 50],
    [10, 0, 35, 25, 30, 20, 15, 30, 40, 45],
    [15, 35, 0, 30, 20, 25, 40, 35, 25, 30],
    [20, 25, 30, 0, 15, 10, 20, 25, 30, 35],
    [25, 30, 20, 15, 0, 30, 35, 40, 45, 50],
    [30, 20, 25, 10, 30, 0, 15, 20, 25, 30],
    [35, 15, 40, 20, 35, 15, 0, 10, 20, 25],
    [40, 30, 35, 25, 40, 20, 10, 0, 15, 20],
    [45, 40, 25, 30, 45, 25, 20, 15, 0, 10],
    [50, 45, 30, 35, 50, 30, 25, 20, 10, 0]
]

# Node to index dictionary (keys = node names, values = their indices)
node_index = {
    "Rishikesh": 0,
    "Haridwar": 1,
    "Neelkanth": 2,
    "Mussoorie": 3,
    "Nainital": 4,
    "Jim Corbett": 5,
    "Valley of Flowers": 6,
    "Auli": 7,
    "Badrinath": 8,
    "Chopta": 9
}

# Example adjacency list (replace with your actual data)
adjacency_list = [
    [1, 2],        # neighbors of node 0
    [0, 3, 5],     # neighbors of node 1
    [0, 4, 6],     # neighbors of node 2
    [1, 7],        # neighbors of node 3
    [2, 8],        # neighbors of node 4
    [1, 9],        # neighbors of node 5
    [2],           # neighbors of node 6
    [3],           # neighbors of node 7
    [4],           # neighbors of node 8
    [5]            # neighbors of node 9
]

planner = ItineraryPlanner(fw_matrix, node_index, adjacency_list)

# Load crowd data from JSON file
with open('crowd.json') as f:
    crowd_status = json.load(f)
planner.set_crowd_status(crowd_status)

@app.route('/api/plan', methods=['POST'])
def plan():
    data = request.json
    start = data['start']
    destinations = data['destinations']
    total_time = data['total_time']

    result = planner.plan_route(start, start, destinations)

    return jsonify({
        'route': result.route,
        'total_time': result.total_time,
        'substitutions': result.substitutions
    })

if __name__ == '__main__':
    app.run(debug=True)
